DJB Fonts - DJB Hand Stitched

To use a base layer for your Hand Stitched Alpha, you could choose Century Gothic and match the size of your stitching to it to create a filleable underlayer for the stitching.